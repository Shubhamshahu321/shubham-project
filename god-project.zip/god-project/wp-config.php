<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'god-project' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Ya{J;zf$AI4c h^*1CMFv]d!$UpphX_19?({lMG+a]A=e|Jrv6*8}APr]2 f_D={' );
define( 'SECURE_AUTH_KEY',  '~2%c5@ lO=2&P];R?c]_3!Ps6.yEZOR]P/FE@2fs6@R~V[5n.q/Fo*]wO*8e^eC/' );
define( 'LOGGED_IN_KEY',    'bm>zX hL(gD[@Tz~ bg,*kAWldf*j  F}N0thW`(z2z%D%06TY~!Q$VHI/+<, vz' );
define( 'NONCE_KEY',        'fK8$/ML_m<bYJsu-pit;S_Q#qr^r?>]8GKuBM,jp$6K-+V9T_HO8,;s}0<o2QG$%' );
define( 'AUTH_SALT',        'bp|7S>]JcT_N-KD&:`o:D${.]j( pdOQ;7|ImgJ)Te4GQx#}z$(]`@a{Yhmsfz{*' );
define( 'SECURE_AUTH_SALT', '-nZU2Ofb5HUX_W7HK|hQcQAvIMZ4E,&EI|jb#c;AGm:MvKr@l];C*N3?9vz1fU&e' );
define( 'LOGGED_IN_SALT',   '1WX_+ndW&qVf?0j1R~l<aYcc1`9C<;<tVPt&/Sn]J2s_G1~?^4.B3{FkO3rk.fNY' );
define( 'NONCE_SALT',       ':KZ-x6VH3rKXjOyt(1TeD,~||u-|<TBPlo+AZYL%;.9A`WF[Vtt{>?Y:qWU~<;DZ' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
